split = (0.3, 0.3)  # Use 30% of data for training, 30% for validation and the rest for testing.
batch_size = 32
window_size = 1  # Number of words on each side of the context window for w2v batches.
